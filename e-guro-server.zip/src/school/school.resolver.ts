import { Args, ID, Int, Mutation, Query, Resolver } from '@nestjs/graphql';
import { UseGuards } from '@nestjs/common';
import { AttendanceStatus } from '@prisma/client';
import { SchoolService } from './school.service';
import { CurrentUser } from '../auth/current-user.decorator';
import { GqlAuthGuard } from '../auth/gql-auth.guard';
import { JwtUser } from '../auth/auth.types';
import {
  Attendance,
  ClassDetail,
  Classroom,
  Dashboard,
  MarkAttendanceInput,
  SaveGradesInput,
  SaveGradesPayload,
  Student,
  StudentProfile,
} from './school.types';

@Resolver()
@UseGuards(GqlAuthGuard)
export class SchoolResolver {
  constructor(private readonly school: SchoolService) {}

  @Query(() => Dashboard)
  dashboard(@CurrentUser() user: JwtUser) {
    return this.school.dashboard(user.sub);
  }

  @Query(() => [Classroom])
  classes(@CurrentUser() user: JwtUser) {
    return this.school.classes(user.sub);
  }

  @Query(() => ClassDetail)
  classDetail(
    @Args('id', { type: () => ID }) id: string,
    @CurrentUser() user: JwtUser,
    @Args('quarter', { type: () => Int, defaultValue: 1 }) quarter: number,
    @Args('date', { nullable: true }) date?: string,
  ) {
    return this.school.classDetail(id, date, quarter, user.sub);
  }

  @Query(() => [Student])
  students(@CurrentUser() user: JwtUser, @Args('search', { nullable: true }) search?: string) {
    return this.school.students(user.sub, search);
  }

  @Query(() => StudentProfile)
  student(@Args('id', { type: () => ID }) id: string, @CurrentUser() user: JwtUser) {
    return this.school.studentProfile(id, user.sub);
  }

  @Mutation(() => Attendance)
  markAttendance(@Args('input') input: MarkAttendanceInput, @CurrentUser() user: JwtUser) {
    return this.school.markAttendance(input, user.sub);
  }

  @Mutation(() => Attendance)
  setAttendance(
    @Args('classroomId', { type: () => ID }) classroomId: string,
    @Args('studentId', { type: () => ID }) studentId: string,
    @Args('date') date: string,
    @Args('status', { type: () => AttendanceStatus }) status: AttendanceStatus,
    @CurrentUser() user: JwtUser,
  ) {
    return this.school.setAttendance(classroomId, studentId, date, status, user.sub);
  }

  @Mutation(() => SaveGradesPayload)
  saveGrades(@Args('input') input: SaveGradesInput, @CurrentUser() user: JwtUser) {
    return this.school.saveGrades(input, user.sub);
  }
}
