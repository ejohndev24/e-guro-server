import { Field, Float, ID, InputType, Int, ObjectType, registerEnumType } from '@nestjs/graphql';
import { AttendanceStatus } from '@prisma/client';
import { IsArray, IsDateString, IsEnum, IsInt, IsNumber, IsString, Max, Min, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

registerEnumType(AttendanceStatus, { name: 'AttendanceStatus' });

@ObjectType()
export class Student {
  @Field(() => ID) id!: string;
  @Field() studentNo!: string;
  @Field() firstName!: string;
  @Field() lastName!: string;
  @Field() fullName!: string;
  @Field({ nullable: true }) email?: string;
}

@ObjectType()
export class Classroom {
  @Field(() => ID) id!: string;
  @Field(() => Int) gradeLevel!: number;
  @Field() section!: string;
  @Field() subject!: string;
  @Field() room!: string;
  @Field() scheduleDay!: string;
  @Field() startTime!: string;
  @Field() endTime!: string;
  @Field(() => Int) studentCount!: number;
  @Field() displayName!: string;
}

@ObjectType()
export class Attendance {
  @Field(() => ID) id!: string;
  @Field() date!: Date;
  @Field({ nullable: true }) checkedAt?: Date;
  @Field(() => AttendanceStatus) status!: AttendanceStatus;
}

@ObjectType()
export class Grade {
  @Field(() => ID) id!: string;
  @Field(() => Int) quarter!: number;
  @Field(() => Float) quiz!: number;
  @Field(() => Float) activity!: number;
  @Field(() => Float) exam!: number;
  @Field(() => Float) finalGrade!: number;
}

@ObjectType()
export class RosterStudent {
  @Field(() => Student) student!: Student;
  @Field(() => Attendance, { nullable: true }) attendance?: Attendance;
  @Field(() => Grade, { nullable: true }) grade?: Grade;
}

@ObjectType()
export class ClassDetail {
  @Field(() => Classroom) classroom!: Classroom;
  @Field(() => [RosterStudent]) roster!: RosterStudent[];
}

@ObjectType()
export class DashboardStats {
  @Field(() => Int) classCount!: number;
  @Field(() => Int) studentCount!: number;
  @Field(() => Float) attendanceRate!: number;
  @Field(() => Int) pendingGrades!: number;
}

@ObjectType()
export class AtRiskStudent {
  @Field(() => Student) student!: Student;
  @Field(() => Classroom) classroom!: Classroom;
  @Field(() => Float) currentGrade!: number;
}

@ObjectType()
export class Dashboard {
  @Field() teacherName!: string;
  @Field(() => DashboardStats) stats!: DashboardStats;
  @Field(() => [Classroom]) classes!: Classroom[];
  @Field(() => [AtRiskStudent]) atRisk!: AtRiskStudent[];
}

@ObjectType()
export class StudentClassSummary {
  @Field(() => Classroom) classroom!: Classroom;
  @Field(() => Float, { nullable: true }) averageGrade?: number;
  @Field(() => Float) attendanceRate!: number;
}

@ObjectType()
export class StudentProfile {
  @Field(() => Student) student!: Student;
  @Field(() => [StudentClassSummary]) classes!: StudentClassSummary[];
  @Field(() => [Attendance]) recentAttendance!: Attendance[];
  @Field(() => [Grade]) grades!: Grade[];
  @Field(() => Float) overallGrade!: number;
  @Field(() => Float) attendanceRate!: number;
}

@InputType()
export class MarkAttendanceInput {
  @Field() @IsString() classroomId!: string;
  @Field() @IsString() qrCode!: string;
  @Field() @IsDateString() date!: string;
  @Field(() => AttendanceStatus) @IsEnum(AttendanceStatus) status!: AttendanceStatus;
}

@InputType()
export class GradeEntryInput {
  @Field() @IsString() studentId!: string;
  @Field(() => Float) @IsNumber() @Min(0) @Max(100) quiz!: number;
  @Field(() => Float) @IsNumber() @Min(0) @Max(100) activity!: number;
  @Field(() => Float) @IsNumber() @Min(0) @Max(100) exam!: number;
}

@InputType()
export class SaveGradesInput {
  @Field() @IsString() classroomId!: string;
  @Field(() => Int) @IsInt() @Min(1) @Max(4) quarter!: number;
  @Field(() => [GradeEntryInput]) @IsArray() @ValidateNested({ each: true }) @Type(() => GradeEntryInput) entries!: GradeEntryInput[];
}

@ObjectType()
export class SaveGradesPayload {
  @Field(() => Int) count!: number;
  @Field(() => [Grade]) grades!: Grade[];
}
