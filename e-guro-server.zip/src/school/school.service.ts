import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { AttendanceStatus, Prisma, UserRole } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { MarkAttendanceInput, SaveGradesInput } from './school.types';

const studentShape = (student: { id: string; studentNo: string; firstName: string; lastName: string; email: string | null }) => ({
  ...student,
  email: student.email ?? undefined,
  fullName: `${student.lastName}, ${student.firstName}`,
});

const classroomShape = (room: {
  id: string; gradeLevel: number; section: string; subject: string; room: string;
  scheduleDay: string; startTime: string; endTime: string; _count?: { enrollments: number };
}) => ({
  ...room,
  studentCount: room._count?.enrollments ?? 0,
  displayName: `Grade ${room.gradeLevel} - ${room.section} • ${room.subject}`,
});

const dayStart = (value = new Date()) => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw new BadRequestException('Invalid date');
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
};

@Injectable()
export class SchoolService {
  constructor(private readonly prisma: PrismaService) {}

  private async teacher(id: string) {
    const teacher = await this.prisma.user.findUnique({ where: { id } });
    if (!teacher || teacher.role !== UserRole.TEACHER) throw new NotFoundException('Teacher account not found');
    return teacher;
  }

  async classes(teacherId: string) {
    const teacher = await this.teacher(teacherId);
    const classes = await this.prisma.classroom.findMany({
      where: { teacherId: teacher.id },
      include: { _count: { select: { enrollments: true } } },
      orderBy: [{ startTime: 'asc' }],
    });
    return classes.map(classroomShape);
  }

  async dashboard(teacherId: string) {
    const teacher = await this.teacher(teacherId);
    const classes = await this.prisma.classroom.findMany({
      where: { teacherId: teacher.id },
      include: { _count: { select: { enrollments: true } } },
      orderBy: { startTime: 'asc' },
    });
    const classIds = classes.map((item) => item.id);
    const studentCount = await this.prisma.student.count({
      where: { enrollments: { some: { classroomId: { in: classIds } } } },
    });
    const [attendanceTotal, attendancePresent, grades, enrollmentCount] = await Promise.all([
      this.prisma.attendance.count({ where: { classroomId: { in: classIds } } }),
      this.prisma.attendance.count({ where: { classroomId: { in: classIds }, status: { in: ['PRESENT', 'LATE'] } } }),
      this.prisma.grade.findMany({
        where: { classroomId: { in: classIds }, quarter: 1 },
        include: { student: true, classroom: { include: { _count: { select: { enrollments: true } } } } },
        orderBy: { finalGrade: 'asc' },
      }),
      this.prisma.enrollment.count({ where: { classroomId: { in: classIds } } }),
    ]);
    const gradedKeys = new Set(grades.map((grade) => `${grade.classroomId}:${grade.studentId}`));

    return {
      teacherName: teacher.name,
      stats: {
        classCount: classes.length,
        studentCount,
        attendanceRate: attendanceTotal ? Math.round((attendancePresent / attendanceTotal) * 1000) / 10 : 0,
        pendingGrades: Math.max(0, enrollmentCount - gradedKeys.size),
      },
      classes: classes.map(classroomShape),
      atRisk: grades.filter((grade) => grade.finalGrade < 75).slice(0, 5).map((grade) => ({
        student: studentShape(grade.student),
        classroom: classroomShape(grade.classroom),
        currentGrade: grade.finalGrade,
      })),
    };
  }

  async classDetail(id: string, date: string | undefined, quarter: number, teacherId: string) {
    const classroom = await this.prisma.classroom.findUnique({
      where: { id, teacherId },
      include: {
        _count: { select: { enrollments: true } },
        enrollments: {
          include: {
            student: {
              include: {
                attendances: { where: { classroomId: id, date: dayStart(date ? new Date(date) : new Date()) }, take: 1 },
                grades: { where: { classroomId: id, quarter }, take: 1 },
              },
            },
          },
          orderBy: { student: { lastName: 'asc' } },
        },
      },
    });
    if (!classroom) throw new NotFoundException('Classroom not found');
    return {
      classroom: classroomShape(classroom),
      roster: classroom.enrollments.map(({ student }) => ({
        student: studentShape(student),
        attendance: student.attendances[0],
        grade: student.grades[0],
      })),
    };
  }

  async students(teacherId: string, search?: string) {
    const where: Prisma.StudentWhereInput = {
      enrollments: { some: { classroom: { teacherId } } },
      ...(search?.trim() ? { OR: [
        { firstName: { contains: search.trim(), mode: 'insensitive' } },
        { lastName: { contains: search.trim(), mode: 'insensitive' } },
        { studentNo: { contains: search.trim(), mode: 'insensitive' } },
      ] } : {}),
    };
    const students = await this.prisma.student.findMany({ where, orderBy: [{ lastName: 'asc' }, { firstName: 'asc' }] });
    return students.map(studentShape);
  }

  async studentProfile(id: string, teacherId: string) {
    const student = await this.prisma.student.findUnique({
      where: { id, enrollments: { some: { classroom: { teacherId } } } },
      include: {
        grades: { orderBy: [{ quarter: 'desc' }, { createdAt: 'desc' }] },
        attendances: { orderBy: { date: 'desc' }, take: 12 },
        enrollments: { include: { classroom: { include: { _count: { select: { enrollments: true } } } } } },
      },
    });
    if (!student) throw new NotFoundException('Student not found');
    const present = student.attendances.filter((item) => ['PRESENT', 'LATE'].includes(item.status)).length;
    const overallGrade = student.grades.length
      ? student.grades.reduce((sum, grade) => sum + grade.finalGrade, 0) / student.grades.length
      : 0;
    const classes = await Promise.all(student.enrollments.map(async ({ classroom }) => {
      const [attendances, grades] = await Promise.all([
        this.prisma.attendance.findMany({ where: { studentId: id, classroomId: classroom.id } }),
        this.prisma.grade.findMany({ where: { studentId: id, classroomId: classroom.id } }),
      ]);
      const attended = attendances.filter((item) => ['PRESENT', 'LATE'].includes(item.status)).length;
      return {
        classroom: classroomShape(classroom),
        attendanceRate: attendances.length ? Math.round((attended / attendances.length) * 1000) / 10 : 0,
        averageGrade: grades.length ? Math.round((grades.reduce((sum, item) => sum + item.finalGrade, 0) / grades.length) * 10) / 10 : undefined,
      };
    }));
    return {
      student: studentShape(student),
      classes,
      recentAttendance: student.attendances,
      grades: student.grades,
      overallGrade: Math.round(overallGrade * 10) / 10,
      attendanceRate: student.attendances.length ? Math.round((present / student.attendances.length) * 1000) / 10 : 0,
    };
  }

  async markAttendance(input: MarkAttendanceInput, teacherId: string) {
    await this.assertOwnsClass(input.classroomId, teacherId);
    const student = await this.prisma.student.findUnique({ where: { qrCode: input.qrCode } });
    if (!student) throw new NotFoundException('This QR code does not belong to a student');
    const enrollment = await this.prisma.enrollment.findUnique({
      where: { studentId_classroomId: { studentId: student.id, classroomId: input.classroomId } },
    });
    if (!enrollment) throw new BadRequestException('Student is not enrolled in this class');
    return this.setAttendance(input.classroomId, student.id, input.date, input.status, teacherId);
  }

  async setAttendance(classroomId: string, studentId: string, date: string, status: AttendanceStatus, teacherId: string) {
    await this.assertOwnsClass(classroomId, teacherId);
    const attendanceDate = dayStart(new Date(date));
    return this.prisma.attendance.upsert({
      where: { studentId_classroomId_date: { studentId, classroomId, date: attendanceDate } },
      update: { status, checkedAt: status === 'ABSENT' ? null : new Date() },
      create: { studentId, classroomId, date: attendanceDate, status, checkedAt: status === 'ABSENT' ? null : new Date() },
    });
  }

  async saveGrades(input: SaveGradesInput, teacherId: string) {
    await this.assertOwnsClass(input.classroomId, teacherId);
    const gradeRows = input.entries.map((entry) => ({
      ...entry,
      finalGrade: Math.round((entry.quiz * 0.2 + entry.activity * 0.3 + entry.exam * 0.5) * 10) / 10,
    }));
    const grades = await this.prisma.$transaction(gradeRows.map((entry) => this.prisma.grade.upsert({
      where: { studentId_classroomId_quarter: { studentId: entry.studentId, classroomId: input.classroomId, quarter: input.quarter } },
      update: { quiz: entry.quiz, activity: entry.activity, exam: entry.exam, finalGrade: entry.finalGrade },
      create: { ...entry, classroomId: input.classroomId, quarter: input.quarter },
    })));
    return { count: grades.length, grades };
  }

  private async assertOwnsClass(classroomId: string, teacherId: string) {
    const classroom = await this.prisma.classroom.findFirst({ where: { id: classroomId, teacherId }, select: { id: true } });
    if (!classroom) throw new NotFoundException('Classroom not found');
  }
}
