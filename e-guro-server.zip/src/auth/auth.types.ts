import { Field, ID, ObjectType, registerEnumType } from '@nestjs/graphql';
import { UserRole } from '@prisma/client';

registerEnumType(UserRole, { name: 'UserRole' });

@ObjectType()
export class AuthUser {
  @Field(() => ID) id!: string;
  @Field() name!: string;
  @Field() email!: string;
  @Field(() => UserRole) role!: UserRole;
  @Field(() => ID, { nullable: true }) schoolId?: string;
  @Field() mustChangePassword!: boolean;
}

@ObjectType()
export class AuthPayload {
  @Field() accessToken!: string;
  @Field(() => AuthUser) user!: AuthUser;
}

export type JwtUser = {
  sub: string;
  email: string;
  role: UserRole;
  schoolId?: string;
};
