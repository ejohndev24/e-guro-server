import { Args, ID, Mutation, Query, Resolver } from '@nestjs/graphql';
import { ForbiddenException, UseGuards } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import { CurrentUser } from '../auth/current-user.decorator';
import { GqlAuthGuard } from '../auth/gql-auth.guard';
import { JwtUser } from '../auth/auth.types';
import { AdminService } from './admin.service';
import { CreateSchoolInput, InvitationPayload, InviteTeacherInput, SchoolDetail, SchoolSummary } from './admin.types';
import { Roles } from './roles.decorator';
import { RolesGuard } from './roles.guard';

@Resolver()
@UseGuards(GqlAuthGuard, RolesGuard)
export class AdminResolver {
  constructor(private readonly admin: AdminService) {}

  @Query(() => [SchoolSummary])
  @Roles(UserRole.SUPER_ADMIN)
  schools() { return this.admin.schools(); }

  @Query(() => SchoolDetail)
  @Roles(UserRole.SUPER_ADMIN, UserRole.SCHOOL_ADMIN)
  school(@Args('id', { type: () => ID }) id: string, @CurrentUser() user: JwtUser) {
    if (user.role === UserRole.SCHOOL_ADMIN && user.schoolId !== id) throw new ForbiddenException('You can only view your school');
    return this.admin.school(id);
  }

  @Mutation(() => InvitationPayload)
  @Roles(UserRole.SUPER_ADMIN)
  createSchool(@Args('input') input: CreateSchoolInput) { return this.admin.createSchool(input); }

  @Mutation(() => InvitationPayload)
  @Roles(UserRole.SUPER_ADMIN, UserRole.SCHOOL_ADMIN)
  inviteTeacher(@Args('input') input: InviteTeacherInput, @CurrentUser() user: JwtUser) {
    if (user.role === UserRole.SCHOOL_ADMIN && user.schoolId !== input.schoolId) throw new ForbiddenException('You can only invite teachers to your school');
    return this.admin.inviteTeacher(input);
  }
}
