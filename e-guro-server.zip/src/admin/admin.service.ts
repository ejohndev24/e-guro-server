import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { UserRole } from '@prisma/client';
import * as argon2 from 'argon2';
import { randomBytes } from 'node:crypto';
import { PrismaService } from '../prisma/prisma.service';
import { CreateSchoolInput, InviteTeacherInput } from './admin.types';
import { MailService } from './mail.service';

@Injectable()
export class AdminService {
  constructor(private readonly prisma: PrismaService, private readonly mail: MailService) {}

  private temporaryPassword() {
    return `${randomBytes(7).toString('base64url')}!aA7`;
  }

  private publicUser(user: { id: string; name: string; email: string; role: UserRole; schoolId: string | null; mustChangePassword: boolean }) {
    return { ...user, schoolId: user.schoolId ?? undefined };
  }

  private summary(school: any) {
    const studentCount = school.classes?.reduce((sum: number, item: any) => sum + (item._count?.enrollments ?? 0), 0) ?? 0;
    return {
      id: school.id,
      name: school.name,
      code: school.code,
      createdAt: school.createdAt,
      teacherCount: school._count?.users ?? 0,
      classCount: school._count?.classes ?? school.classes?.length ?? 0,
      studentCount,
    };
  }

  async schools() {
    const schools = await this.prisma.school.findMany({
      include: { _count: { select: { users: { where: { role: UserRole.TEACHER } }, classes: true } }, classes: { select: { _count: { select: { enrollments: true } } } } },
      orderBy: { createdAt: 'desc' },
    });
    return schools.map((school) => this.summary(school));
  }

  async school(id: string) {
    const school = await this.prisma.school.findUnique({
      where: { id },
      include: { users: { orderBy: [{ role: 'asc' }, { name: 'asc' }] }, _count: { select: { users: { where: { role: UserRole.TEACHER } }, classes: true } }, classes: { select: { _count: { select: { enrollments: true } } } } },
    });
    if (!school) throw new NotFoundException('School not found');
    return { school: this.summary(school), users: school.users.map((user) => this.publicUser(user)) };
  }

  async createSchool(input: CreateSchoolInput) {
    const code = input.code.trim().toUpperCase();
    const email = input.adminEmail.trim().toLowerCase();
    const existing = await this.prisma.user.findUnique({ where: { email } });
    if (existing) throw new BadRequestException('That email already has an account');
    const temporaryPassword = this.temporaryPassword();
    const school = await this.prisma.school.create({
      data: {
        name: input.name.trim(),
        code,
        users: { create: { name: input.adminName.trim(), email, passwordHash: await argon2.hash(temporaryPassword), role: UserRole.SCHOOL_ADMIN, mustChangePassword: true } },
      },
      include: { users: true },
    });
    const administrator = school.users[0]!;
    const emailSent = await this.mail.sendTemporaryPassword({ name: administrator.name, email, schoolName: school.name, temporaryPassword, role: 'SCHOOL_ADMIN' });
    return { user: this.publicUser(administrator), emailSent };
  }

  async inviteTeacher(input: InviteTeacherInput) {
    const school = await this.prisma.school.findUnique({ where: { id: input.schoolId } });
    if (!school) throw new NotFoundException('School not found');
    const email = input.email.trim().toLowerCase();
    if (await this.prisma.user.findUnique({ where: { email } })) throw new BadRequestException('That email already has an account');
    const temporaryPassword = this.temporaryPassword();
    const teacher = await this.prisma.user.create({
      data: { name: input.name.trim(), email, passwordHash: await argon2.hash(temporaryPassword), role: UserRole.TEACHER, schoolId: school.id, mustChangePassword: true },
    });
    const emailSent = await this.mail.sendTemporaryPassword({ name: teacher.name, email, schoolName: school.name, temporaryPassword, role: 'TEACHER' });
    return { user: this.publicUser(teacher), emailSent };
  }
}
