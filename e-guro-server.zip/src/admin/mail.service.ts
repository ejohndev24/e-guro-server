import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import nodemailer, { Transporter } from 'nodemailer';

@Injectable()
export class MailService {
  private readonly transport?: Transporter;

  constructor(private readonly config: ConfigService) {
    const host = config.get<string>('SMTP_HOST');
    if (host) {
      this.transport = nodemailer.createTransport({
        host,
        port: config.get<number>('SMTP_PORT', 587),
        secure: config.get<string>('SMTP_SECURE', 'false') === 'true',
        auth: {
          user: config.get<string>('SMTP_USER'),
          pass: config.get<string>('SMTP_PASSWORD'),
        },
      });
    }
  }

  async sendTemporaryPassword(input: { name: string; email: string; schoolName: string; temporaryPassword: string; role: string }) {
    const subject = `Your Teacher Hub account for ${input.schoolName}`;
    const text = [
      `Hello ${input.name},`, '',
      `An account was created for you as ${input.role.toLowerCase().replace('_', ' ')} at ${input.schoolName}.`,
      `Username: ${input.email}`,
      `Temporary password: ${input.temporaryPassword}`, '',
      'Sign in and change this password immediately. Do not share it with anyone.',
    ].join('\n');
    if (!this.transport) {
      console.log(`\n[DEV EMAIL]\nTo: ${input.email}\nSubject: ${subject}\n${text}\n`);
      return false;
    }
    await this.transport.sendMail({ from: this.config.get('SMTP_FROM'), to: input.email, subject, text });
    return true;
  }
}
