import { Field, ID, InputType, Int, ObjectType } from '@nestjs/graphql';
import { UserRole } from '@prisma/client';
import { IsEmail, IsString, Length, MinLength } from 'class-validator';
import { AuthUser } from '../auth/auth.types';

@ObjectType()
export class SchoolSummary {
  @Field(() => ID) id!: string;
  @Field() name!: string;
  @Field() code!: string;
  @Field(() => Int) teacherCount!: number;
  @Field(() => Int) studentCount!: number;
  @Field(() => Int) classCount!: number;
  @Field() createdAt!: Date;
}

@ObjectType()
export class SchoolDetail {
  @Field(() => SchoolSummary) school!: SchoolSummary;
  @Field(() => [AuthUser]) users!: AuthUser[];
}

@InputType()
export class CreateSchoolInput {
  @Field() @IsString() @MinLength(2) name!: string;
  @Field() @IsString() @Length(2, 12) code!: string;
  @Field() @IsString() @MinLength(2) adminName!: string;
  @Field() @IsEmail() adminEmail!: string;
}

@InputType()
export class InviteTeacherInput {
  @Field(() => ID) @IsString() schoolId!: string;
  @Field() @IsString() @MinLength(2) name!: string;
  @Field() @IsEmail() email!: string;
}

@ObjectType()
export class InvitationPayload {
  @Field(() => AuthUser) user!: AuthUser;
  @Field() emailSent!: boolean;
}
