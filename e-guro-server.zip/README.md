# E-Guro Server

NestJS GraphQL API for the E-Guro teacher mobile app and administration portal.

## Local setup

```bash
npm install
cp .env.example .env
docker compose up -d postgres
npm run db:generate
npm run db:migrate -- --name init
npm run db:seed
npm run start:dev
```

Endpoints:

- Health: `http://localhost:4000/health`
- GraphQL: `http://localhost:4000/graphql`

Development accounts created by the seed:

```text
Admin: admin@teacherhub.local / Admin123!
Teacher: alex.rivera@school.edu / Teacher123!
```

The development seed clears application tables. Never run it in production.

## Production database

```bash
npx prisma migrate deploy
npm run db:bootstrap-admin
```

Configure `DATABASE_URL`, `DIRECT_URL`, `JWT_SECRET`, CORS, SMTP, and the bootstrap administrator values using `.env.example`. Remove the bootstrap password after creating the production administrator.
